package com.example.StudentApi.service; 
 
import com.example.StudentApi.model.Student; import org.springframework.stereotype.Service; 
 
import java.util.ArrayList; import java.util.List; 
 
@Service 
public class StudentService { 
 
    private List<Student> students = new ArrayList<>(); 
 
    public StudentService() { 
        students.add(new Student(101, "Rahul", "Computer"));         students.add(new Student(102, "Priya", "IT")); 
    } 
 
    public List<Student> getAllStudents() {         return students; 
    } 
 
    public Student getStudent(int id) {         return students.stream() 
                .filter(s -> s.getId() == id) 
                .findFirst() 
                .orElse(null); 
    } 
 
    public Student addStudent(Student student) { 
        students.add(student); 
        return student; 
    } 
 
    public Student updateStudent(int id, Student student) { 
 
        for(Student s : students){             if(s.getId()==id){ 
                s.setName(student.getName()); 
                s.setCourse(student.getCourse());                 return s; 
            } 
        } 
        return null; 
    } 
 
    public String deleteStudent(int id){ 
 
        students.removeIf(s -> s.getId()==id);         return "Student Deleted Successfully"; 
    } 
} 
