package com.example.StudentApi.controller; 
 
import com.example.StudentApi.model.Student; import com.example.StudentApi.service.StudentService; import org.springframework.beans.factory.annotation.Autowired; import org.springframework.web.bind.annotation.*; 
 
import java.util.List; 
 
@RestController 
@RequestMapping("/students") public class StudentController { 
 
    @Autowired 
    StudentService service; 
 
    // GET ALL 
    @GetMapping
    public List<Student> getStudents() 
    {         
    	return service.getAllStudents(); 
    } 
 
    // GET BY ID 
    @GetMapping("/{id}") 
    public Student getStudent(@PathVariable int id) 
    {        
    	return service.getStudent(id); 
    } 
 
    // CREATE     
    @PostMapping 
    public Student addStudent(@RequestBody Student student) 
    {         
    	return service.addStudent(student); 
    } 
 
    // UPDATE 
    @PutMapping("/{id}")    
    public Student updateStudent(@PathVariable int id, @RequestBody Student student) 
    {         
    	return service.updateStudent(id, student); 
    } 
 
    // DELETE 
    @DeleteMapping("/{id}") 
    public String deleteStudent(@PathVariable int id) {        
    	return service.deleteStudent(id); 
    } 
} 
